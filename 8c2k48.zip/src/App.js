import { useEffect, useState } from "react";

export default function App() {
  //declarar o estado
  //podemos usar useState("") para mostrar vazio
  const [advice, setAdvice] = useState("Hello World!");
  //state para mostrar quantos conselhos foram mostrados
  const [count, setCount] = useState(0);
  //função assíncrona
  async function getAdvice() {
    //chamada a api
    const res = await fetch("https://api.adviceslip.com/advice");
    //converte a resposta em json
    const data = await res.json();
    //mostra a resposta em consola
    console.log(data.slip.advice);
    //mudar o estado para a resposta da api
    setAdvice(data.slip.advice);
    //contador
    setCount((c) => c + 1);
  }

  useEffect(function () {
    //neste caso usamos esta função ao carregar em vez do hello world
    //chama afunção getAdvice
    getAdvice();
    //é necessário colocar este array vazio para evitar que a função fique em loop
  }, []);

  // count aparece com count -1 por devido ao modo strict a contagem inicial aparecia como 2
  return (
    <div>
      <h1>{advice}</h1>
      <button onClick={getAdvice}>Get advice</button>
      <Message count={count - 1} />
    </div>
  );

  function Message(props) {
    return (
      <p>
        You have read <strong>{props.count}</strong> pieces of advice.
      </p>
    );
  }
}
