import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";

function App() {
  return (
    <div className="card">
      <Avatar />
      <div className="data">
        <Intro />
        {/* Should contain one Skill component for each web dev skill that you have, customized with props*/}
        <SkillList />
      </div>
    </div>
  );
}

function Avatar() {
  return <img className="avatar" src={"Ava.jpg"} alt={""} />;
}

function Intro() {
  return (
    <div className="data">
      <h1>Edgar Lavado</h1>
      <p>
        Full-stack web developer and student at Udemy. When not coding or taking
        a course. I like to play board games, to cook (and eat), or just to
        enjoy the nice weather of Portugal.
      </p>
    </div>
  );
}

function SkillList() {
  return (
    <div className="skill-list">
      <Skill name="HTML+CSS" emoji="💪" color="Blue" />
      <Skill name="JavaScript" emoji="💪" color="Yellow" />
      <Skill name="Web Design" emoji="💪" color="Green" />
      <Skill name="Git and GitHub" emoji="👍" color="Red" />
      <Skill name="React" emoji="💪" color="Azure" />
      <Skill name="Svelte" emoji="👶" color="Orange" />
    </div>
  );
}

function Skill(props) {
  return (
    <div className="skill" style={{ backgroundColor: props.color }}>
      <span>{props.name}</span>
      <span>{props.emogi}</span>
    </div>
  );
}

const rootElement = document.getElementById("root");
const root = createRoot(rootElement);

root.render(
  <StrictMode>
    <App />
  </StrictMode>
);
